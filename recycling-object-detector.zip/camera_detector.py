import cv2
import torch

# YOLOv5 모델 로드
model = torch.hub.load('.yolov5/runs/train/recycle_detector20/weights/best.pt', 'yolov5s')

# 카메라 설정
cap = cv2.VideoCapture(0)  # 0번 카메라 사용

while True:
    # 영상 프레임 읽기
    ret, frame = cap.read()

    # 결과 출력을 위한 프레임 복사
    result = frame.copy()

    # YOLOv5 모델로 객체 탐지
    results = model(frame)

    # 검출된 객체 루프
    for result in results.xyxy[0]:
        # 신뢰도가 임계값 이상인 경우만 처리
        if result[-1] > 0.5:
            # 바운딩 박스 및 클래스 레이블 추출
            x1, y1, x2, y2, class_id = result.astype(int)

            # 바운딩 박스 그리기
            cv2.rectangle(result, (x1, y1), (x2, y2), (255, 0, 0), 2)

            # 클래스 레이블 출력
            class_name = model.names[class_id]
            cv2.putText(result, class_name, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

    # 결과 영상 출력
    cv2.imshow('Object Detection', result)

    # 종료 키 입력
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 카메라 및 창 닫기
cap.release()
cv2.destroyAllWindows()